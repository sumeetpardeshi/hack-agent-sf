import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import MobileInterface from "@/components/mobile-interface"
import SystemArchitecture from "@/components/system-architecture"
import DemoQrCode from "@/components/demo-qr-code"
import Features from "@/components/features"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 to-white dark:from-slate-950 dark:to-slate-900">
      <header className="container mx-auto py-12">
        <div className="flex flex-col items-center text-center mb-12">
          <div className="inline-block bg-gradient-to-r from-sky-600 to-indigo-600 text-transparent bg-clip-text">
            <h1 className="text-5xl md:text-6xl font-bold mb-2">Twil-Flare Travels</h1>
          </div>
          <p className="text-xl text-sky-700 dark:text-sky-400 font-medium">AI-Powered Travel Agent</p>
          <div className="mt-6 max-w-2xl">
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
              Text your itinerary to an AI and get instant travel updates, reminders, and actions—without downloading an
              app.
            </p>
          </div>
        </div>
      </header>

      <main className="container mx-auto pb-20">
        <Tabs defaultValue="demo" className="w-full max-w-5xl mx-auto">
          <TabsList className="grid w-full grid-cols-4 mb-12">
            <TabsTrigger value="demo" className="text-sm md:text-base">
              Demo
            </TabsTrigger>
            <TabsTrigger value="features" className="text-sm md:text-base">
              Features
            </TabsTrigger>
            <TabsTrigger value="architecture" className="text-sm md:text-base">
              Architecture
            </TabsTrigger>
            <TabsTrigger value="qrcode" className="text-sm md:text-base">
              QR Code
            </TabsTrigger>
          </TabsList>

          <TabsContent value="demo" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
            <MobileInterface />
          </TabsContent>

          <TabsContent value="features" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
            <Features />
          </TabsContent>

          <TabsContent value="architecture" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
            <SystemArchitecture />
          </TabsContent>

          <TabsContent value="qrcode" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
            <DemoQrCode />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

