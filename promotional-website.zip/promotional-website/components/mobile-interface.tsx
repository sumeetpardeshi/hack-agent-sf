"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { FileText, Send, Check, AlertTriangle, Clock, Paperclip, Smile } from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Card, CardContent } from "@/components/ui/card"

type MessageType = {
  id: string
  sender: "user" | "assistant"
  content: string
  timestamp: string
  type?: "document" | "alert" | "normal" | "emergency"
}

// Add new type for API response
type UploadResponse = {
  file_path: string
}

type RunResponse = {
  outputs: [{
    outputs: [{
      results: {
        message: {
          data: {
            text: string;
          }
        }
      }
    }]
  }]
}

export default function MobileInterface() {
  const [activeDemo, setActiveDemo] = useState<"basic" | "proactive" | "action" | "emergency">("basic")
  const [input, setInput] = useState("")
  const [isUploading, setIsUploading] = useState(false)
  const [messages, setMessages] = useState<MessageType[]>([])
  const [uploadedFilePath, setUploadedFilePath] = useState<string>("")

  const basicConversation: MessageType[] = [
    {
      id: "1",
      sender: "user",
      content: "[Flight Itinerary PDF]",
      timestamp: "10:30 AM",
      type: "document",
    },
    {
      id: "2",
      sender: "assistant",
      content: "Processing your travel documents...",
      timestamp: "10:30 AM",
    },
    {
      id: "3",
      sender: "assistant",
      content: "I've saved your itinerary for JFK→LAX on March 5-8. You're all set! Ask me anything about your trip.",
      timestamp: "10:30 AM",
    },
    {
      id: "4",
      sender: "user",
      content: "What's my hotel address?",
      timestamp: "10:31 AM",
    },
    {
      id: "5",
      sender: "assistant",
      content:
        "You're staying at the Hilton LAX: 5711 W Century Blvd, Los Angeles, CA 90045. Check-in is at 3:00 PM on March 5.",
      timestamp: "10:31 AM",
    },
  ]

  const proactiveConversation: MessageType[] = [
    {
      id: "1",
      sender: "assistant",
      content: "🔔 Travel Alert: Your flight AA1234 to LAX tomorrow has a gate change. Now departing from Terminal 4, Gate B7 (previously Gate B12).",
      timestamp: "2:15 PM",
      type: "alert"
    },
    {
      id: "2",
      sender: "assistant",
      content: "⏰ Check-in Reminder: Online check-in is now available for your flight. Would you like me to help you check in?",
      timestamp: "2:16 PM"
    },
    {
      id: "3",
      sender: "user",
      content: "Yes please",
      timestamp: "2:17 PM"
    },
    {
      id: "4",
      sender: "assistant",
      content: "✅ I've completed your check-in! Your boarding pass has been sent to your email. \n\n🌤️ Weather Update for LAX: Expect sunny conditions tomorrow, high of 75°F (24°C). Perfect flying weather!",
      timestamp: "2:18 PM"
    },
    {
      id: "5",
      sender: "assistant",
      content: "🚗 Traffic Alert: Heavy traffic expected on I-405 tomorrow morning. Recommend leaving 45 minutes earlier than planned for LAX.",
      timestamp: "8:00 PM",
      type: "alert"
    }
  ]

  const actionConversation: MessageType[] = [
    {
      id: "1",
      sender: "user",
      content: "What's my flight status?",
      timestamp: "9:15 AM"
    },
    {
      id: "2",
      sender: "assistant",
      content: "Checking your AA1234 flight...\n\n✈️ Status: On Time\nDeparture: 11:45 AM from LAX T4\nArrival: 8:15 PM at JFK T8\nCurrent Weather: Clear skies at both airports",
      timestamp: "9:15 AM"
    },
    {
      id: "3",
      sender: "user",
      content: "Can you find me a restaurant near my gate?",
      timestamp: "9:16 AM"
    },
    {
      id: "4",
      sender: "assistant",
      content: "📍 Near Gate B7, I found:\n\n1. Shake Shack (⭐4.3) - 2 min walk\n2. LA Farmers Market (⭐4.1) - 5 min walk\n3. Urth Caffé (⭐4.4) - 3 min walk\n\nWould you like to see menus or hours for any of these?",
      timestamp: "9:16 AM"
    },
    {
      id: "5",
      sender: "user",
      content: "Show me Shake Shack's menu",
      timestamp: "9:17 AM"
    },
    {
      id: "6",
      sender: "assistant",
      content: "🍔 Shake Shack Menu Highlights:\n• ShackBurger - $7.29\n• Chicken Shack - $7.99\n• Fries - $3.99\n• Shakes - $5.99\n\nHours: 6:00 AM - 10:00 PM\nCurrently: Open ✅\nEstimated Wait Time: 10-15 mins",
      timestamp: "9:17 AM"
    }
  ]

  const emergencyConversation: MessageType[] = [
    {
      id: "1",
      sender: "user",
      content: "HELP! My connecting flight is delayed and I might miss my next flight",
      timestamp: "4:30 PM",
      type: "emergency"
    },
    {
      id: "2",
      sender: "assistant",
      content: "🚨 PRIORITY ALERT: Analyzing your situation...\n\nCurrent Flight AA789: 2 hour delay\nConnection AA456: 45 min layover\n\nRisk Assessment: High risk of missing connection",
      timestamp: "4:30 PM",
      type: "emergency"
    },
    {
      id: "3",
      sender: "assistant",
      content: "I've found 3 alternative options:\n\n1️⃣ AA908 (6:30 PM) - 3 seats left\n2️⃣ AA234 (7:15 PM) - 1 seat left\n3️⃣ AA567 (8:00 PM) - 12 seats left\n\nShould I help rebook you on any of these flights? Option 1 would get you to your destination closest to your original arrival time.",
      timestamp: "4:31 PM",
      type: "emergency"
    },
    {
      id: "4",
      sender: "user",
      content: "Yes, please book option 1",
      timestamp: "4:32 PM"
    },
    {
      id: "5",
      sender: "assistant",
      content: "✅ CONFIRMED: I've rebooked you on AA908\n\n📱 New boarding pass sent to your phone\n🛫 New Gate: C15\n⏰ Boarding: 6:00 PM\n\nI've also:\n• Updated your hotel about late arrival\n• Requested meal voucher for delay\n• Arranged priority security access\n\nHead to Gate C15 now. Need anything else?",
      timestamp: "4:33 PM",
      type: "emergency"
    },
    {
      id: "6",
      sender: "user",
      content: "Will my luggage be transferred?",
      timestamp: "4:34 PM"
    },
    {
      id: "7",
      sender: "assistant",
      content: "✅ I've confirmed with baggage services:\n• Your luggage will be automatically transferred to AA908\n• Track your bags with code: #JF892X\n• Estimated delivery: On time with your new flight\n\nI'll notify you when your bags are loaded onto the new aircraft.",
      timestamp: "4:34 PM",
      type: "alert"
    }
  ]

  // Add effect to handle demo switching
  useEffect(() => {
    switch (activeDemo) {
      case "proactive":
        setMessages(proactiveConversation)
        break
      case "action":
        setMessages(actionConversation)
        break
      case "emergency":
        setMessages(emergencyConversation)
        break
      case "basic":
        // Clear messages for basic mode - will be populated by actual API interactions
        setMessages([])
        break
    }
  }, [activeDemo])

  // Update getActiveConversation to only return mock data for non-basic scenarios
  const getActiveConversation = () => {
    if (activeDemo === "basic") {
      return messages // Return actual messages for basic mode
    }
    
    switch (activeDemo) {
      case "proactive":
        return proactiveConversation
      case "action":
        return actionConversation
      case "emergency":
        return emergencyConversation
      default:
        return messages
    }
  }

  const generateUniqueId = (() => {
    let counter = 0;
    return () => {
      counter += 1;
      return `${Date.now()}-${counter}`;
    };
  })();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMessage = {
      id: generateUniqueId(),
      sender: "user",
      content: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
    setMessages(prev => [...prev, userMessage])

    const currentInput = input
    setInput("")

    try {
      // Add processing message
      setMessages(prev => [...prev, {
        id: generateUniqueId(),
        sender: "assistant",
        content: "Processing your request...",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }])

      const runResponse = await fetch(
        'http://localhost:7860/api/v1/run/87bd8610-289c-4705-ba84-a1c9a0e58368?stream=false',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer AstraCS:FdOqMvFHWIffvOdkGfJQDLcL:abbe0570e58bbfa7dfeb6f0132755cb6220481ee9be5f0c8b851f3d3652ceb09'
          },
          body: JSON.stringify({
            output_type: "chat",
            input_type: "chat",
            tweaks: {
              "ChatInput-C9cJV": {
                background_color: "",
                chat_icon: "",
                files: uploadedFilePath, // Use the stored file path
                input_value: currentInput,
                sender: "User",
                sender_name: "User",
                session_id: "",
                should_store_message: true,
                text_color: ""
              }
            }
          })
        }
      )

      const runData: RunResponse = await runResponse.json()
      
      // Extract the message text from the nested response
      const messageText = runData.outputs[0]?.outputs[0]?.results?.message?.data?.text

      // Remove the processing message
      setMessages(prev => prev.filter(msg => msg.content !== "Processing your request..."))

      // Add the response message
      setMessages(prev => [...prev, {
        id: generateUniqueId(),
        sender: "assistant",
        content: messageText || "I couldn't process your request. Please try again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }])

    } catch (error) {
      console.error('Error processing message:', error)
      setMessages(prev => [...prev, {
        id: generateUniqueId(),
        sender: "assistant",
        content: "Sorry, I encountered an error processing your request. Please try again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: "alert"
      }])
    }
  }

  const handleFileUpload = async (file: File) => {
    try {
      setIsUploading(true)
      
      const fileInput = document.getElementById('file-upload') as HTMLInputElement;
      if (fileInput) {
        fileInput.value = '';
      }
      
      // Show file upload message
      setMessages(prev => [...prev, {
        id: generateUniqueId(),
        sender: "user",
        content: `[${file.name}]`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: "document"
      }])

      // Show processing message
      setMessages(prev => [...prev, {
        id: generateUniqueId(),
        sender: "assistant",
        content: "Processing your travel documents...",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }])

      const formData = new FormData()
      formData.append('file', file)

      const uploadResponse = await fetch(
        'http://localhost:7860/api/v1/files/upload/87bd8610-289c-4705-ba84-a1c9a0e58368',
        {
          method: 'POST',
          body: formData,
        }
      )
      
      const uploadData: UploadResponse = await uploadResponse.json()
      // Store the file path for future use
      setUploadedFilePath(uploadData.file_path)

      const runResponse = await fetch(
        'http://localhost:7860/api/v1/run/87bd8610-289c-4705-ba84-a1c9a0e58368?stream=false',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer AstraCS:FdOqMvFHWIffvOdkGfJQDLcL:abbe0570e58bbfa7dfeb6f0132755cb6220481ee9be5f0c8b851f3d3652ceb09'
          },
          body: JSON.stringify({
            output_type: "chat",
            input_type: "chat",
            tweaks: {
              "ChatInput-C9cJV": {
                files: uploadData.file_path,
                input_value: "This is travel itinerary of customer. help extract the travel information.",
                sender: "User",
                sender_name: "User",
                should_store_message: true
              }
            }
          })
        }
      )

      const runData: RunResponse = await runResponse.json()
      
      // Extract the message text from the nested response
      const messageText = runData.outputs[0]?.outputs[0]?.results?.message?.data?.text

      // Parse the JSON string from the message if it exists
      let formattedMessage = "I've analyzed your travel documents. Here's what I found:\n\n";

      try {
        const jsonMatch = messageText?.match(/```json\n([\s\S]*?)\n```/);
        if (jsonMatch) {
          const flightData = JSON.parse(jsonMatch[1]);
          
          if (flightData.outboundFlight) {
            // Handle round trip itinerary
            formattedMessage += formatFlightDetails(flightData);
          } else if (Array.isArray(flightData.flights)) {
            // Handle multiple flights
            formattedMessage += flightData.flights
              .map((flight: any) => formatFlightDetails(flight))
              .join('\n\n');
          }
          
          formattedMessage += '\n\nI can help you with:\n' +
                             '• Flight status updates\n' +
                             '• Check-in reminders\n' +
                             '• Travel requirements\n' +
                             '• Weather updates\n\n' +
                             'What would you like to know?';
        } else {
          formattedMessage += messageText || "I couldn't parse the flight information. Please try again.";
        }
      } catch (e) {
        console.error('Error parsing flight data:', e);
        formattedMessage += "I encountered an error processing the flight details. Please try again.";
      }

      // Show the analysis result in a chat bubble
      setMessages(prev => [...prev, {
        id: generateUniqueId(),
        sender: "assistant",
        content: formattedMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }])

    } catch (error) {
      console.error('Error processing file:', error)
      setMessages(prev => [...prev, {
        id: generateUniqueId(),
        sender: "assistant",
        content: "Sorry, I encountered an error processing your file. Please try again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: "alert"
      }])
    } finally {
      setIsUploading(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileUpload(file)
    }
  }

  const formatFlightDetails = (flight: any) => {
    const formatTime = (time: string, timeZone: string) => `${time} ${timeZone}`;
    
    if (flight.outboundFlight) {
      // Handle round trip format
      return `📍 Outbound Flight:\n` +
             `${flight.outboundFlight.travelCompanyName} ${flight.outboundFlight.flightNumber}\n` +
             `From: ${flight.outboundFlight.takeOff}\n` +
             `To: ${flight.outboundFlight.landing}\n` +
             `Date: ${flight.outboundFlight.date}\n` +
             `Departure: ${formatTime(flight.outboundFlight.time, flight.outboundFlight.timeZone)}\n\n` +
             `📍 Return Flight:\n` +
             `${flight.returnFlight.travelCompanyName} ${flight.returnFlight.flightNumber}\n` +
             `From: ${flight.returnFlight.takeOff}\n` +
             `To: ${flight.returnFlight.landing}\n` +
             `Date: ${flight.returnFlight.date}\n` +
             `Departure: ${formatTime(flight.returnFlight.time, flight.returnFlight.timeZone)}`;
    } else {
      // Handle single flight format
      return `✈️ Flight ${flight.flightNumber}\n` +
             `${flight.travelCompanyName}\n` +
             `From: ${flight.takeOff}\n` +
             `To: ${flight.landing}\n` +
             `Date: ${flight.date}\n` +
             `Departure: ${formatTime(flight.time, flight.timeZone)}`;
    }
  };

  return (
    <div className="flex flex-col md:flex-row gap-10 items-start">
      <div className="w-full md:w-1/3 mb-6 md:mb-0">
        <h2 className="text-xl font-semibold mb-6 text-sky-800 dark:text-sky-300">Demo Scenarios</h2>
        <div className="space-y-3">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={activeDemo === "basic" ? "default" : "outline"}
                  className="w-full justify-start h-auto py-3 transition-all"
                  onClick={() => setActiveDemo("basic")}
                >
                  <div className="flex items-center">
                    <div
                      className={cn(
                        "mr-3 p-2 rounded-full",
                        activeDemo === "basic" ? "bg-white/20" : "bg-sky-100 dark:bg-sky-900",
                      )}
                    >
                      <FileText
                        className={cn(
                          "h-5 w-5",
                          activeDemo === "basic" ? "text-white" : "text-sky-700 dark:text-sky-400",
                        )}
                      />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">Basic Interaction</div>
                      <div
                        className={cn(
                          "text-xs mt-1",
                          activeDemo === "basic" ? "text-sky-100" : "text-muted-foreground",
                        )}
                      >
                        Upload documents & ask questions
                      </div>
                    </div>
                  </div>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>See how users can upload travel documents and ask basic questions</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={activeDemo === "proactive" ? "default" : "outline"}
                  className="w-full justify-start h-auto py-3 transition-all"
                  onClick={() => setActiveDemo("proactive")}
                >
                  <div className="flex items-center">
                    <div
                      className={cn(
                        "mr-3 p-2 rounded-full",
                        activeDemo === "proactive" ? "bg-white/20" : "bg-sky-100 dark:bg-sky-900",
                      )}
                    >
                      <Clock
                        className={cn(
                          "h-5 w-5",
                          activeDemo === "proactive" ? "text-white" : "text-sky-700 dark:text-sky-400",
                        )}
                      />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">Proactive Alerts</div>
                      <div
                        className={cn(
                          "text-xs mt-1",
                          activeDemo === "proactive" ? "text-sky-100" : "text-muted-foreground",
                        )}
                      >
                        Timely reminders & updates
                      </div>
                    </div>
                  </div>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>See how the system sends proactive alerts about upcoming travel</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={activeDemo === "action" ? "default" : "outline"}
                  className="w-full justify-start h-auto py-3 transition-all"
                  onClick={() => setActiveDemo("action")}
                >
                  <div className="flex items-center">
                    <div
                      className={cn(
                        "mr-3 p-2 rounded-full",
                        activeDemo === "action" ? "bg-white/20" : "bg-sky-100 dark:bg-sky-900",
                      )}
                    >
                      <Check
                        className={cn(
                          "h-5 w-5",
                          activeDemo === "action" ? "text-white" : "text-sky-700 dark:text-sky-400",
                        )}
                      />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">Action Execution</div>
                      <div
                        className={cn(
                          "text-xs mt-1",
                          activeDemo === "action" ? "text-sky-100" : "text-muted-foreground",
                        )}
                      >
                        Perform tasks on user's behalf
                      </div>
                    </div>
                  </div>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>See how the system performs tasks like checking flight status</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={activeDemo === "emergency" ? "default" : "outline"}
                  className="w-full justify-start h-auto py-3 transition-all"
                  onClick={() => setActiveDemo("emergency")}
                >
                  <div className="flex items-center">
                    <div
                      className={cn(
                        "mr-3 p-2 rounded-full",
                        activeDemo === "emergency" ? "bg-white/20" : "bg-sky-100 dark:bg-sky-900",
                      )}
                    >
                      <AlertTriangle
                        className={cn(
                          "h-5 w-5",
                          activeDemo === "emergency" ? "text-white" : "text-sky-700 dark:text-sky-400",
                        )}
                      />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">Emergency Mode</div>
                      <div
                        className={cn(
                          "text-xs mt-1",
                          activeDemo === "emergency" ? "text-sky-100" : "text-muted-foreground",
                        )}
                      >
                        Critical assistance when needed
                      </div>
                    </div>
                  </div>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>See how the system responds to emergency situations</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        <Card className="mt-8 border-sky-100 dark:border-sky-900">
          <CardContent className="p-4">
            <h3 className="text-sm font-medium mb-2 text-sky-800 dark:text-sky-300">About This Demo</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Select a scenario to see how TwinFlare interacts with users in different situations. Each demo showcases
              a key capability of the AI travel assistant.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="w-full md:w-2/3 bg-white dark:bg-slate-800 rounded-xl shadow-xl overflow-hidden border border-gray-200 dark:border-gray-700 max-w-md mx-auto">
        <div className="bg-gradient-to-r from-sky-600 to-indigo-600 text-white p-4">
          <div className="flex items-center">
            <div className="flex-1">
              <h3 className="font-semibold">TwinFlare</h3>
              <p className="text-xs text-sky-100">Your AI Travel Assistant</p>
            </div>
            <Badge variant="outline" className="text-white border-white/30 bg-white/10">
              +1 (669) 261-3333
            </Badge>
          </div>
        </div>

        <div className="h-[500px] overflow-y-auto p-4 bg-gray-50 dark:bg-slate-900">
          <div className="space-y-4">
            {getActiveConversation().map((message) => (
              <div key={message.id} className={cn("flex", message.sender === "user" ? "justify-end" : "justify-start")}>
                {message.sender === "assistant" && (
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarFallback className="bg-gradient-to-r from-sky-600 to-indigo-600 text-white text-xs">
                      TF
                    </AvatarFallback>
                  </Avatar>
                )}

                <div
                  className={cn(
                    "max-w-[80%] rounded-2xl p-3 shadow-sm",
                    message.sender === "user"
                      ? "bg-gradient-to-r from-sky-600 to-indigo-600 text-white"
                      : message.type === "emergency"
                        ? "bg-red-100 border border-red-200 text-red-800 dark:bg-red-900/30 dark:border-red-800 dark:text-red-300"
                        : message.type === "alert"
                          ? "bg-amber-100 border border-amber-200 text-amber-800 dark:bg-amber-900/30 dark:border-amber-800 dark:text-amber-300"
                          : "bg-white border border-gray-100 dark:bg-slate-800 dark:border-slate-700 dark:text-gray-100",
                    message.type === "document" && "flex items-center",
                  )}
                >
                  {message.type === "document" ? (
                    <>
                      <FileText className="h-5 w-5 mr-2" />
                      <span>{message.content}</span>
                    </>
                  ) : message.type === "emergency" ? (
                    <div>
                      {message.content.includes("PRIORITY ALERT") && (
                        <AlertTriangle className="h-5 w-5 mb-1 text-red-600 dark:text-red-400" />
                      )}
                      {message.content}
                    </div>
                  ) : (
                    message.content
                  )}
                  <div
                    className={cn(
                      "text-xs mt-1",
                      message.sender === "user"
                        ? "text-sky-100"
                        : message.type === "emergency"
                          ? "text-red-600 dark:text-red-400"
                          : message.type === "alert"
                            ? "text-amber-600 dark:text-amber-400"
                            : "text-gray-500 dark:text-gray-400",
                    )}
                  >
                    {message.timestamp}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-3 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-slate-800">
          {activeDemo === "basic" ? (
            <form onSubmit={handleSubmit} className="flex items-center">
              <input
                type="file"
                id="file-upload"
                className="hidden"
                onChange={handleFileChange}
              />
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="text-gray-500 dark:text-gray-400"
                onClick={() => document.getElementById('file-upload')?.click()}
                disabled={isUploading}
              >
                <Paperclip className="h-5 w-5" />
              </Button>
              <Input
                type="text"
                placeholder="Type a message..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 mx-2 bg-gray-100 dark:bg-slate-700 border-0"
              />
              <Button type="button" size="icon" variant="ghost" className="text-gray-500 dark:text-gray-400 mr-1">
                <Smile className="h-5 w-5" />
              </Button>
              <Button
                type="submit"
                size="icon"
                className="bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700"
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          ) : (
            <div className="text-sm text-center text-gray-500 dark:text-gray-400 py-2">
              This is a demo conversation. Switch to Basic mode to try live interactions.
            </div>
          )}
          {isUploading && (
            <div className="text-sm text-gray-500 mt-2">
              Uploading and processing file...
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

