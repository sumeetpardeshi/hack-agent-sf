import { CloudCog, Database, MessageSquare, Zap, FileText, BrainCircuit, Bell, ArrowRight } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SystemArchitecture() {
  return (
    <div className="space-y-12">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-sky-600 to-indigo-600 text-transparent bg-clip-text mb-3">
          Technical Architecture
        </h2>
        <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
          Twil-Flare Travels leverages cutting-edge technologies to deliver a seamless travel assistant experience.
        </p>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="components">Components</TabsTrigger>
          <TabsTrigger value="flow">Data Flow</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="focus-visible:outline-none focus-visible:ring-0">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <TechCard
              icon={<MessageSquare className="h-5 w-5" />}
              title="Communication Layer"
              description="Twilio SMS/MMS Integration"
              sponsor="Twilio"
              features={[
                "Receive user messages and documents",
                "Send responses and proactive alerts",
                "Schedule timely reminders",
              ]}
            />

            <TechCard
              icon={<CloudCog className="h-5 w-5" />}
              title="Edge Computing"
              description="Cloudflare Workers & Services"
              sponsor="Cloudflare"
              features={[
                "Serverless backend with 100-200ms response times",
                "Durable Objects for persistent state",
                "Vectorize for semantic information retrieval",
                "Queues for asynchronous tasks",
              ]}
            />

            <TechCard
              icon={<BrainCircuit className="h-5 w-5" />}
              title="Intelligence Layer"
              description="OpenAI & Unstructured"
              sponsor="OpenAI & Unstructured"
              features={[
                "GPT-4 for natural language understanding",
                "Function calling for structured actions",
                "Unstructured API for document parsing",
              ]}
            />
          </div>
        </TabsContent>

        <TabsContent value="components" className="focus-visible:outline-none focus-visible:ring-0">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ComponentCard
              title="Document Processor"
              description="Extracts structured data from travel documents"
              tech="Unstructured API + Cloudflare Workers"
              features={[
                "PDF parsing and text extraction",
                "Entity recognition for travel details",
                "Classification of document types",
              ]}
            />

            <ComponentCard
              title="Query Interpreter"
              description="Translates natural language to actionable intents"
              tech="OpenAI GPT-4 + Function Calling"
              features={["Intent recognition", "Entity extraction", "Context-aware understanding"]}
            />

            <ComponentCard
              title="State Manager"
              description="Maintains user context and trip details"
              tech="Cloudflare Durable Objects + Vectorize"
              features={[
                "Persistent conversation state",
                "Semantic memory for past interactions",
                "User preference storage",
              ]}
            />

            <ComponentCard
              title="Action Engine"
              description="Executes tasks based on user requests"
              tech="Cloudflare Workers + External APIs"
              features={["Flight status checking", "Weather forecasting", "Reminder scheduling"]}
            />

            <ComponentCard
              title="Alert Scheduler"
              description="Triggers timely notifications"
              tech="Cloudflare Queues + Twilio API"
              features={["Time-based triggers", "Event-based alerts", "Priority notification system"]}
            />

            <ComponentCard
              title="Response Generator"
              description="Creates natural language replies"
              tech="OpenAI GPT-4 + Twilio"
              features={[
                "Context-aware responses",
                "Personalized messaging",
                "Multi-format support (text, structured data)",
              ]}
            />
          </div>
        </TabsContent>

        <TabsContent value="flow" className="focus-visible:outline-none focus-visible:ring-0">
          <div className="relative">
            <div className="hidden md:block absolute left-1/2 top-0 bottom-0 border-l-2 border-dashed border-sky-200 dark:border-sky-800 -translate-x-1/2 z-0"></div>

            <div className="relative z-10 space-y-12">
              <FlowStep
                number="1"
                title="Document Submission"
                leftContent="User sends travel document via SMS/MMS"
                rightContent="Twilio forwards to Cloudflare Worker"
                icon={<FileText className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              />

              <FlowStep
                number="2"
                title="Data Extraction"
                leftContent="Document processed by Unstructured API"
                rightContent="Structured data stored in Cloudflare Durable Objects"
                icon={<Database className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              />

              <FlowStep
                number="3"
                title="User Interaction"
                leftContent="User sends query via SMS"
                rightContent="Intent recognized via OpenAI"
                icon={<MessageSquare className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              />

              <FlowStep
                number="4"
                title="Processing & Response"
                leftContent="Action executed or query processed"
                rightContent="Response generated and sent via Twilio"
                icon={<Zap className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              />

              <FlowStep
                number="5"
                title="Proactive Monitoring"
                leftContent="System monitors travel events"
                rightContent="Sends timely alerts about upcoming events"
                icon={<Bell className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              />
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function TechCard({ icon, title, description, sponsor, features }) {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md border-sky-100 dark:border-sky-900">
      <CardHeader className="pb-2 bg-gradient-to-r from-sky-50 to-indigo-50 dark:from-sky-950 dark:to-indigo-950">
        <Badge className="w-fit mb-2 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-600 hover:to-indigo-600">
          {sponsor}
        </Badge>
        <CardTitle className="flex items-center text-sky-700 dark:text-sky-400">
          <div className="bg-white dark:bg-slate-800 p-2 rounded-full mr-2">{icon}</div>
          {title}
        </CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <ul className="space-y-2 text-sm">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <span className="bg-sky-100 dark:bg-sky-900 p-1 rounded-full mr-2 mt-0.5">
                <Check className="h-3 w-3 text-sky-700 dark:text-sky-400" />
              </span>
              {feature}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

function ComponentCard({ title, description, tech, features }) {
  return (
    <Card className="border-sky-100 dark:border-sky-900 transition-all hover:shadow-md">
      <CardHeader className="pb-2">
        <Badge
          variant="outline"
          className="w-fit mb-2 border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-400"
        >
          {tech}
        </Badge>
        <CardTitle className="text-sky-700 dark:text-sky-400">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <ul className="space-y-2 text-sm">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <span className="bg-sky-100 dark:bg-sky-900 p-1 rounded-full mr-2 mt-0.5">
                <Check className="h-3 w-3 text-sky-700 dark:text-sky-400" />
              </span>
              {feature}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

function FlowStep({ number, title, leftContent, rightContent, icon }) {
  return (
    <div className="flex flex-col md:flex-row items-center gap-4">
      <div className="md:w-1/2 md:text-right">
        <h4 className="font-medium text-sky-700 dark:text-sky-400 mb-1">{leftContent}</h4>
        <div className="flex items-center justify-end md:hidden">
          <ArrowRight className="h-4 w-4 text-sky-500 dark:text-sky-600 mx-2" />
        </div>
      </div>
      <div className="relative">
        <div className="bg-gradient-to-r from-sky-600 to-indigo-600 rounded-full p-3 relative z-10">
          <div className="absolute -top-1 -right-1 bg-white dark:bg-slate-800 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold text-sky-700 dark:text-sky-400 border-2 border-sky-600">
            {number}
          </div>
          {icon}
        </div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-lg font-bold text-sky-800 dark:text-sky-300 whitespace-nowrap hidden md:block">
          {title}
        </div>
      </div>
      <div className="md:w-1/2">
        <div className="md:hidden font-medium text-sky-700 dark:text-sky-400 mb-1 text-center">{title}</div>
        <h4 className="font-medium text-sky-700 dark:text-sky-400 mb-1">{rightContent}</h4>
      </div>
    </div>
  )
}

function Check(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  )
}

