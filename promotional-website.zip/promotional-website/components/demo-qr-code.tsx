import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, Smartphone, QrCode, FileText } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DemoQrCode() {
  return (
    <div className="flex flex-col items-center justify-center">
      <div className="max-w-md w-full text-center mb-8">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-sky-600 to-indigo-600 text-transparent bg-clip-text mb-3">
          Try Twil-Flare Travels
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          Scan the QR code with your phone to start interacting with Twil-Flare Travels directly.
        </p>
      </div>

      <Tabs defaultValue="qrcode" className="w-full max-w-md">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="qrcode">QR Code</TabsTrigger>
          <TabsTrigger value="instructions">Instructions</TabsTrigger>
        </TabsList>

        <TabsContent value="qrcode" className="focus-visible:outline-none focus-visible:ring-0">
          <Card className="border-sky-100 dark:border-sky-900 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-sky-50 to-indigo-50 dark:from-sky-950 dark:to-indigo-950 pb-4">
              <div className="flex items-center justify-center mb-2">
                <QrCode className="h-6 w-6 text-sky-700 dark:text-sky-400 mr-2" />
                <CardTitle>Demo QR Code</CardTitle>
              </div>
              <CardDescription className="text-center">Text your travel documents to +1 (555) 123-4567</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center p-6">
              <div className="bg-white p-4 rounded-lg shadow-md mb-6 relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-sky-600/10 to-indigo-600/10 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"></div>
                <img src="/placeholder.svg?height=250&width=250" alt="QR Code" className="w-[250px] h-[250px]" />
              </div>
            </CardContent>
            <CardFooter className="bg-gradient-to-r from-sky-50 to-indigo-50 dark:from-sky-950 dark:to-indigo-950 flex flex-col gap-4 p-4">
              <div className="grid grid-cols-2 gap-4 w-full">
                <Button className="flex items-center justify-center bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700">
                  <Download className="mr-2 h-4 w-4" />
                  Sample PDF
                </Button>
                <Button
                  variant="outline"
                  className="flex items-center justify-center border-sky-200 dark:border-sky-800"
                >
                  <Smartphone className="mr-2 h-4 w-4" />
                  SMS: +1 (555) 123-4567
                </Button>
              </div>

              <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
                <p>For demo purposes only. Sample PDFs are provided to showcase functionality.</p>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="instructions" className="focus-visible:outline-none focus-visible:ring-0">
          <Card className="border-sky-100 dark:border-sky-900">
            <CardHeader className="bg-gradient-to-r from-sky-50 to-indigo-50 dark:from-sky-950 dark:to-indigo-950">
              <div className="flex items-center justify-center mb-2">
                <FileText className="h-6 w-6 text-sky-700 dark:text-sky-400 mr-2" />
                <CardTitle>Demo Instructions</CardTitle>
              </div>
              <CardDescription>Follow these steps to experience Twil-Flare Travels</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <ol className="space-y-4 text-gray-700 dark:text-gray-300">
                <li className="flex items-start">
                  <div className="bg-gradient-to-r from-sky-600 to-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0 mt-0.5">
                    1
                  </div>
                  <div>
                    <p className="font-medium">Scan the QR code</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Use your phone's camera to scan the QR code above
                    </p>
                  </div>
                </li>

                <li className="flex items-start">
                  <div className="bg-gradient-to-r from-sky-600 to-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0 mt-0.5">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Send a text message</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Text "Hello" to +1 (555) 123-4567 to start the conversation
                    </p>
                  </div>
                </li>

                <li className="flex items-start">
                  <div className="bg-gradient-to-r from-sky-600 to-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0 mt-0.5">
                    3
                  </div>
                  <div>
                    <p className="font-medium">Forward the sample PDF</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Download and forward the sample PDF to the same number
                    </p>
                  </div>
                </li>

                <li className="flex items-start">
                  <div className="bg-gradient-to-r from-sky-600 to-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0 mt-0.5">
                    4
                  </div>
                  <div>
                    <p className="font-medium">Ask questions about your trip</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Try "What's my flight number?" or "Check if my flight is delayed"
                    </p>
                  </div>
                </li>

                <li className="flex items-start">
                  <div className="bg-gradient-to-r from-sky-600 to-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0 mt-0.5">
                    5
                  </div>
                  <div>
                    <p className="font-medium">Try emergency mode</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Text "HELP" to see how Twil-Flare Travels handles emergency situations
                    </p>
                  </div>
                </li>
              </ol>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

