import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, MessageSquare, Bell, Zap, Brain, Clock, Shield, Smartphone } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Features() {
  return (
    <div className="space-y-12">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-sky-600 to-indigo-600 text-transparent bg-clip-text mb-3">
          Key Agent Capabilities
        </h2>
        <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
          Twil-Flare Travels is a fully autonomous travel assistant with powerful capabilities.
        </p>
      </div>

      <Tabs defaultValue="capabilities" className="w-full">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
          <TabsTrigger value="capabilities">Capabilities</TabsTrigger>
          <TabsTrigger value="benefits">User Benefits</TabsTrigger>
        </TabsList>

        <TabsContent value="capabilities" className="focus-visible:outline-none focus-visible:ring-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard
              icon={<FileText className="h-10 w-10 text-white" />}
              iconBg="from-blue-500 to-cyan-500"
              title="Document Processing"
              description="Autonomously extracts structured data from travel documents"
              details={[
                "Parses flight itineraries, hotel bookings, and event tickets",
                "Identifies key travel details like dates, times, and locations",
                "Works with PDFs, emails, and screenshots",
                "Powered by Unstructured's document parsing API",
              ]}
            />

            <FeatureCard
              icon={<MessageSquare className="h-10 w-10 text-white" />}
              iconBg="from-indigo-500 to-purple-500"
              title="Natural Language Understanding"
              description="Interprets complex travel queries with context awareness"
              details={[
                "Understands natural language questions about your trip",
                "Maintains conversation context for follow-up questions",
                "Handles ambiguous queries with clarification",
                "Powered by OpenAI's GPT-4 language model",
              ]}
            />

            <FeatureCard
              icon={<Bell className="h-10 w-10 text-white" />}
              iconBg="from-amber-500 to-orange-500"
              title="Proactive Monitoring"
              description="Sends timely alerts about upcoming travel events"
              details={[
                "Day-before flight reminders with weather information",
                "Morning-of updates with traffic conditions",
                "Real-time flight delay notifications",
                "Post-landing guidance for transportation options",
              ]}
            />

            <FeatureCard
              icon={<Zap className="h-10 w-10 text-white" />}
              iconBg="from-green-500 to-emerald-500"
              title="Action Execution"
              description="Performs useful travel-related tasks on user's behalf"
              details={[
                "Checks flight status in real-time",
                "Provides weather forecasts for destination cities",
                "Sets reminders for important travel tasks",
                "Offers emergency assistance with rebooking options",
              ]}
            />

            <FeatureCard
              icon={<Brain className="h-10 w-10 text-white" />}
              iconBg="from-rose-500 to-pink-500"
              title="Contextual Memory"
              description="Maintains trip details and user preferences over time"
              details={[
                "Remembers all details of your itinerary without asking twice",
                "Stores preferences like seat choices and meal requirements",
                "Maintains history of past interactions for reference",
                "Leverages Cloudflare Vectorize for semantic memory",
              ]}
            />

            <FeatureCard
              icon={<Shield className="h-10 w-10 text-white" />}
              iconBg="from-sky-500 to-blue-500"
              title="Emergency Assistance"
              description="Provides critical help when travel plans go wrong"
              details={[
                "Prioritizes urgent information during disruptions",
                "Offers alternative options for canceled flights",
                "Helps with rebooking and accommodation changes",
                "Provides real-time guidance during travel emergencies",
              ]}
            />
          </div>
        </TabsContent>

        <TabsContent value="benefits" className="focus-visible:outline-none focus-visible:ring-0">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <BenefitCard
              icon={<Smartphone className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              title="No App Required"
              description="Works entirely through SMS/MMS messaging - no downloads, no accounts to create, just text and go."
            />

            <BenefitCard
              icon={<Clock className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              title="Ultra-Fast Responses"
              description="Optimized for 100-200ms response times using Cloudflare's edge computing for that 'magical' feeling."
            />

            <BenefitCard
              icon={<Bell className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              title="Always Available"
              description="24/7 assistance for all your travel needs, from planning to in-trip support and emergency situations."
            />

            <BenefitCard
              icon={<Shield className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              title="Privacy First"
              description="Your travel data is securely processed and never shared with third parties or used for advertising."
            />

            <BenefitCard
              icon={<Zap className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              title="Proactive Intelligence"
              description="Anticipates your needs and sends timely alerts before you even have to ask."
            />

            <BenefitCard
              icon={<Brain className="h-6 w-6 text-sky-700 dark:text-sky-400" />}
              title="Contextual Understanding"
              description="Remembers your preferences and past interactions to provide personalized assistance."
            />
          </div>

          <div className="mt-12 bg-gradient-to-r from-sky-50 to-indigo-50 dark:from-sky-950/50 dark:to-indigo-950/50 rounded-xl p-6 border border-sky-100 dark:border-sky-900">
            <div className="text-center mb-6">
              <h3 className="text-xl font-semibold text-sky-800 dark:text-sky-300">Why Users Love Twil-Flare Travels</h3>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                Our AI travel assistant makes travel stress-free and enjoyable
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-sky-100 dark:border-sky-900 flex items-start">
                <div className="bg-gradient-to-r from-sky-100 to-indigo-100 dark:from-sky-900 dark:to-indigo-900 p-2 rounded-full mr-3">
                  <Check className="h-5 w-5 text-sky-700 dark:text-sky-400" />
                </div>
                <div>
                  <h4 className="font-medium text-sky-700 dark:text-sky-400">Universal Accessibility</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Works on any phone with SMS capability, no smartphone required
                  </p>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-sky-100 dark:border-sky-900 flex items-start">
                <div className="bg-gradient-to-r from-sky-100 to-indigo-100 dark:from-sky-900 dark:to-indigo-900 p-2 rounded-full mr-3">
                  <Check className="h-5 w-5 text-sky-700 dark:text-sky-400" />
                </div>
                <div>
                  <h4 className="font-medium text-sky-700 dark:text-sky-400">Zero Learning Curve</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Natural language interface that anyone can use immediately
                  </p>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-sky-100 dark:border-sky-900 flex items-start">
                <div className="bg-gradient-to-r from-sky-100 to-indigo-100 dark:from-sky-900 dark:to-indigo-900 p-2 rounded-full mr-3">
                  <Check className="h-5 w-5 text-sky-700 dark:text-sky-400" />
                </div>
                <div>
                  <h4 className="font-medium text-sky-700 dark:text-sky-400">Reduced Travel Stress</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Proactive alerts help avoid common travel pitfalls
                  </p>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-sky-100 dark:border-sky-900 flex items-start">
                <div className="bg-gradient-to-r from-sky-100 to-indigo-100 dark:from-sky-900 dark:to-indigo-900 p-2 rounded-full mr-3">
                  <Check className="h-5 w-5 text-sky-700 dark:text-sky-400" />
                </div>
                <div>
                  <h4 className="font-medium text-sky-700 dark:text-sky-400">Time Saving</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Instant access to travel information without searching
                  </p>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function FeatureCard({ icon, iconBg, title, description, details }) {
  return (
    <Card className="border-sky-100 dark:border-sky-900 overflow-hidden transition-all hover:shadow-md group">
      <CardHeader className="pb-2">
        <div className="mb-4 -mt-1 -ml-1">
          <div className={`bg-gradient-to-r ${iconBg} p-4 rounded-lg w-fit group-hover:shadow-md transition-all`}>
            {icon}
          </div>
        </div>
        <CardTitle className="text-sky-800 dark:text-sky-300 group-hover:text-sky-700 dark:group-hover:text-sky-400 transition-colors">
          {title}
        </CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <ul className="space-y-2 text-sm">
          {details.map((detail, index) => (
            <li key={index} className="flex items-start">
              <span className="bg-sky-100 dark:bg-sky-900 p-1 rounded-full mr-2 mt-0.5">
                <Check className="h-3 w-3 text-sky-700 dark:text-sky-400" />
              </span>
              {detail}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

function BenefitCard({ icon, title, description }) {
  return (
    <Card className="border-sky-100 dark:border-sky-900 transition-all hover:shadow-md group">
      <CardContent className="p-6">
        <div className="flex flex-col items-center text-center">
          <div className="bg-gradient-to-r from-sky-100 to-indigo-100 dark:from-sky-900 dark:to-indigo-900 p-3 rounded-full mb-4 group-hover:shadow-md transition-all">
            {icon}
          </div>
          <h3 className="font-medium text-sky-800 dark:text-sky-300 mb-2 group-hover:text-sky-700 dark:group-hover:text-sky-400 transition-colors">
            {title}
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">{description}</p>
        </div>
      </CardContent>
    </Card>
  )
}

function Check(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  )
}

